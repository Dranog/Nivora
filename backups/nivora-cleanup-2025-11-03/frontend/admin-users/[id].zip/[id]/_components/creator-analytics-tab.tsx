'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Eye,
  TrendingUp,
  Users,
  ThumbsUp,
  MessageSquare,
  Share2,
  FileText,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { useCreatorAnalytics } from '../_hooks/useCreatorData';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// ============================================
// PROPS INTERFACE
// ============================================
interface CreatorAnalyticsTabProps {
  userId: string;
}

export function CreatorAnalyticsTab({ userId }: CreatorAnalyticsTabProps) {
  const { data, isLoading, error } = useCreatorAnalytics(userId);

  // ============================================
  // LOADING STATE
  // ============================================
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  // ============================================
  // ERROR STATE
  // ============================================
  if (error || !data) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <p className="text-gray-600">Erreur lors du chargement des analytics</p>
        <Button onClick={() => window.location.reload()} variant="outline" className="mt-4">
          Réessayer
        </Button>
      </div>
    );
  }

  // ============================================
  // EXTRACT DATA WITH DEFAULTS
  // ============================================
  const performance = data?.performance || {
    views: { total: 0, thisMonth: 0, trend: [] },
    likes: { total: 0, thisMonth: 0, trend: [] },
    comments: { total: 0, thisMonth: 0, trend: [] },
    shares: { total: 0, thisMonth: 0, trend: [] },
    engagementRate: 0,
  };

  const audience = data?.audience || {
    totalFollowers: 0,
    newFollowersThisMonth: 0,
    demographics: {
      age: [],
      gender: [],
      location: [],
    },
  };

  const content = data?.content || {
    totalPosts: 0,
    postsThisMonth: 0,
    averagePostsPerWeek: 0,
    mostEngagingType: 'VIDEO',
  };

  // ============================================
  // HELPER FUNCTIONS
  // ============================================
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('fr-FR').format(num);
  };

  return (
    <div className="space-y-6">
      {/* ============================================ */}
      {/* KPI CARDS - PERFORMANCE */}
      {/* ============================================ */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vues totales</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(performance?.views?.total || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(performance?.views?.thisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taux d&apos;engagement</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(performance?.engagementRate || 0).toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground mt-1">Moyenne sur 30 jours</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Abonnés</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(audience?.totalFollowers || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(audience?.newFollowersThisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contenus publiés</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(content?.totalPosts || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(content?.postsThisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ============================================ */}
      {/* VIEWS TREND CHART */}
      {/* ============================================ */}
      <Card>
        <CardHeader>
          <CardTitle>Évolution des vues - 30 derniers jours</CardTitle>
        </CardHeader>
        <CardContent>
          {(performance?.views?.trend || []).length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Aucune donnée de tendance disponible
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={(performance?.views?.trend || []).slice(-30)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  name="Vues"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* ============================================ */}
      {/* ENGAGEMENT METRICS */}
      {/* ============================================ */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Likes totaux</CardTitle>
            <ThumbsUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(performance?.likes?.total || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(performance?.likes?.thisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Commentaires</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(performance?.comments?.total || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(performance?.comments?.thisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Partages</CardTitle>
            <Share2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(performance?.shares?.total || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{formatNumber(performance?.shares?.thisMonth || 0)} ce mois
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ============================================ */}
      {/* ENGAGEMENT TRENDS */}
      {/* ============================================ */}
      <Card>
        <CardHeader>
          <CardTitle>Tendances d&apos;engagement</CardTitle>
        </CardHeader>
        <CardContent>
          {(performance?.likes?.trend || []).length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Aucune donnée de tendance disponible
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={(performance?.likes?.trend || []).slice(-30)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="#ec4899"
                  strokeWidth={2}
                  name="Likes"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* ============================================ */}
      {/* CONTENT STATS */}
      {/* ============================================ */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Statistiques de contenu</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Total de contenus</span>
                <span className="text-2xl font-bold">{formatNumber(content?.totalPosts || 0)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Publiés ce mois</span>
                <span className="text-2xl font-bold">{formatNumber(content?.postsThisMonth || 0)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Moyenne par semaine</span>
                <span className="text-2xl font-bold">{(content?.averagePostsPerWeek || 0).toFixed(1)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Type le plus engageant</span>
                <span className="text-lg font-semibold text-blue-600">
                  {content?.mostEngagingType || 'N/A'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ============================================ */}
        {/* DEMOGRAPHICS */}
        {/* ============================================ */}
        <Card>
          <CardHeader>
            <CardTitle>Démographie de l&apos;audience</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Age Distribution */}
              {(audience?.demographics?.age || []).length > 0 ? (
                <div>
                  <p className="text-sm font-medium mb-3">Répartition par âge</p>
                  <div className="space-y-2">
                    {(audience?.demographics?.age || []).slice(0, 5).map((ageGroup: { range: string; count: number }, index: number) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <span>{ageGroup.range}</span>
                        <span className="font-semibold">{formatNumber(ageGroup.count)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500 text-sm">
                  Aucune donnée d&apos;âge disponible
                </div>
              )}

              {/* Gender Distribution */}
              {(audience?.demographics?.gender || []).length > 0 ? (
                <div>
                  <p className="text-sm font-medium mb-3">Répartition par genre</p>
                  <div className="space-y-2">
                    {(audience?.demographics?.gender || []).map((gender: { type: string; count: number }, index: number) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <span>{gender.type}</span>
                        <span className="font-semibold">{formatNumber(gender.count)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500 text-sm">
                  Aucune donnée de genre disponible
                </div>
              )}

              {/* Location Distribution */}
              {(audience?.demographics?.location || []).length > 0 ? (
                <div>
                  <p className="text-sm font-medium mb-3">Top 5 pays</p>
                  <div className="space-y-2">
                    {(audience?.demographics?.location || []).slice(0, 5).map((location: { country: string; count: number }, index: number) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <span>{location.country}</span>
                        <span className="font-semibold">{formatNumber(location.count)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500 text-sm">
                  Aucune donnée de localisation disponible
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ============================================ */}
      {/* INFO BOX */}
      {/* ============================================ */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-700 text-sm">
            <TrendingUp className="h-4 w-4" />
            Mode démonstration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-blue-900">
            🎭 <strong>MODE DÉMO :</strong> Les données affichées sont générées automatiquement pour la démonstration.
            Les statistiques de performance, d&apos;engagement et d&apos;audience sont simulées.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
