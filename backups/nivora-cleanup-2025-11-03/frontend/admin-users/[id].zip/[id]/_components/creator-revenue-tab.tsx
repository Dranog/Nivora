'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
  DollarSign,
  TrendingUp,
  Users,
  Heart,
  Eye,
  ShoppingBag,
  Download,
  CreditCard,
  CheckCircle,
  Clock,
  XCircle,
  Loader2,
  AlertTriangle,
} from 'lucide-react';
import type {
  CreatorRevenue,
  CreatorTip,
  CreatorPPVSale,
  CreatorPayoutHistory,
  CreatorSubscriber,
} from '../_types/creator-types';
import type { MarketplaceTransaction } from '../_types/fan-supervision-types';
import { useCreatorRevenue } from '../_hooks/useCreatorData';
import { adminToasts } from '@/lib/toasts';
import { toast } from 'sonner';

interface CreatorRevenueTabProps {
  userId: string;
}

export function CreatorRevenueTab({ userId }: CreatorRevenueTabProps) {
  const [selectedTab, setSelectedTab] = useState<'all' | 'subscriptions' | 'tips' | 'ppv' | 'marketplace'>('all');

  // Fetch revenue data
  const { data: revenueData, isLoading, error } = useCreatorRevenue(userId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  if (error || !revenueData) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <p className="text-gray-600">Erreur lors du chargement des revenus</p>
        <Button onClick={() => window.location.reload()} variant="outline" className="mt-4">
          Réessayer
        </Button>
      </div>
    );
  }

  // Extract data with safe defaults
  const revenue = revenueData?.revenue || {
    totalEarnings: 0,
    currentMonthEarnings: 0,
    monthlyRecurring: 0,
    breakdown: {
      subscriptions: 0,
      tips: 0,
      ppv: 0,
      marketplace: 0,
      total: 0,
    },
    subscriptionPlans: {
      basic: { price: 0, count: 0 },
      vip: { price: 0, count: 0 },
      premium: { price: 0, count: 0 },
    },
  };

  const tips = revenueData?.tips || [];
  const ppvSales = revenueData?.ppvSales || [];
  const payoutHistory = revenueData?.payoutHistory || [];
  const activeSubscribers = revenueData?.activeSubscribers || [];
  const marketplaceTransactions = revenueData?.marketplaceTransactions || [];

  // Helper function to safely calculate percentage
  const safePercentage = (value: number, total: number): number => {
    if (total === 0) return 0;
    return Math.round((value / total) * 100);
  };

  const handleViewSubscriber = (subscriberId: string, fanId: string) => {
    console.log('👤 [SUBSCRIBER] Viewing subscriber:', { subscriberId, fanId });
    toast.info(`Ouverture profil fan ${fanId}`);
    // TODO: Navigation vers profil fan
  };

  const handleCancelSubscription = async (subscriberId: string, fanName: string) => {
    const confirmed = window.confirm(
      `Êtes-vous sûr de vouloir annuler l'abonnement de ${fanName} ?\n\nCette action est irréversible.`
    );

    if (!confirmed) {
      console.log('❌ [CANCEL SUB] User cancelled');
      return;
    }

    console.log('🚫 [CANCEL SUB] Cancelling subscription:', subscriberId);

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success(`Abonnement de ${fanName} annulé avec succès`);
      console.log('✅ [CANCEL SUB] Subscription cancelled');
    } catch (error) {
      console.error('❌ [CANCEL SUB] Error:', error);
      toast.error("Erreur lors de l'annulation");
    }
  };

  const handleViewMarketplaceTransaction = (transactionId: string) => {
    console.log('🛒 [MARKETPLACE] Viewing transaction:', transactionId);
    toast.info('Redirection vers transaction marketplace');
    // TODO: Navigation vers onglet marketplace
  };

  const handleDownloadInvoice = (payoutId: string) => {
    console.log('📄 [INVOICE] Generating internal report for payout:', payoutId);
    toast.info('Génération du rapport interne');
    toast.warning('Les rapports sont consultables uniquement en interne (RGPD)', { duration: 4000 });
    // RGPD: Pas de téléchargement, seulement modal lecture seule
  };

  const getPayoutStatusBadge = (status: string) => {
    const config = {
      completed: { label: 'Versé', className: 'bg-green-50 text-green-700 border-green-200', icon: CheckCircle },
      pending: { label: 'En attente', className: 'bg-yellow-50 text-yellow-700 border-yellow-200', icon: Clock },
      failed: { label: 'Échoué', className: 'bg-red-50 text-red-700 border-red-200', icon: XCircle },
    };
    return config[status as keyof typeof config] || config.pending;
  };

  const getSubscriptionPlanBadge = (plan: string) => {
    const config = {
      basic: { label: 'Basic', className: 'bg-gray-50 text-gray-700 border-gray-200' },
      vip: { label: 'VIP', className: 'bg-blue-50 text-blue-700 border-blue-200' },
      premium: { label: 'Premium', className: 'bg-purple-50 text-purple-700 border-purple-200' },
    };
    return config[plan as keyof typeof config] || config.basic;
  };

  // Calculate top tippers
  const topTippers = tips
    .reduce((acc, tip) => {
      const existing = acc.find((t) => t.fanId === tip.fanId);
      if (existing) {
        existing.total += tip.amount;
        existing.count += 1;
      } else {
        acc.push({
          fanId: tip.fanId,
          fanName: tip.fanName,
          fanAvatar: tip.fanAvatar,
          total: tip.amount,
          count: 1,
        });
      }
      return acc;
    }, [] as Array<{ fanId: string; fanName: string; fanAvatar: string; total: number; count: number }>)
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Earnings */}
        <Card className="border-l-4 border-green-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Revenus totaux</p>
                <p className="text-3xl font-bold text-gray-900">€{(revenue?.totalEarnings || 0).toFixed(2)}</p>
                <p className="text-xs text-gray-500 mt-1">Depuis création</p>
              </div>
              <div className="p-3 bg-green-50 rounded-full">
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Month */}
        <Card className="border-l-4 border-blue-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Revenus mois en cours</p>
                <p className="text-3xl font-bold text-gray-900">€{(revenue?.currentMonthEarnings || 0).toFixed(2)}</p>
                <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  +12.5% vs mois dernier
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-full">
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Monthly Recurring */}
        <Card className="border-l-4 border-purple-600">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Revenus récurrents (MRR)</p>
                <p className="text-3xl font-bold text-gray-900">€{(revenue?.monthlyRecurring || 0).toFixed(2)}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {(revenue?.subscriptionPlans?.basic?.count || 0) + (revenue?.subscriptionPlans?.vip?.count || 0) + (revenue?.subscriptionPlans?.premium?.count || 0)} abonnés
                </p>
              </div>
              <div className="p-3 bg-purple-50 rounded-full">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Répartition des revenus (mois en cours)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-blue-900">Abonnements</span>
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-2xl font-bold text-blue-900">€{(revenue?.breakdown?.subscriptions || 0).toFixed(2)}</p>
              <p className="text-xs text-blue-700 mt-1">
                {safePercentage(revenue?.breakdown?.subscriptions || 0, revenue?.breakdown?.total || 0)}% du total
              </p>
            </div>

            <div className="p-4 bg-pink-50 border border-pink-200 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-pink-900">Tips</span>
                <Heart className="w-5 h-5 text-pink-600" />
              </div>
              <p className="text-2xl font-bold text-pink-900">€{(revenue?.breakdown?.tips || 0).toFixed(2)}</p>
              <p className="text-xs text-pink-700 mt-1">
                {safePercentage(revenue?.breakdown?.tips || 0, revenue?.breakdown?.total || 0)}% du total
              </p>
            </div>

            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-purple-900">PPV</span>
                <Eye className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-2xl font-bold text-purple-900">€{(revenue?.breakdown?.ppv || 0).toFixed(2)}</p>
              <p className="text-xs text-purple-700 mt-1">
                {safePercentage(revenue?.breakdown?.ppv || 0, revenue?.breakdown?.total || 0)}% du total
              </p>
            </div>

            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-orange-900">Marketplace</span>
                <ShoppingBag className="w-5 h-5 text-orange-600" />
              </div>
              <p className="text-2xl font-bold text-orange-900">€{(revenue?.breakdown?.marketplace || 0).toFixed(2)}</p>
              <p className="text-xs text-orange-700 mt-1">
                {safePercentage(revenue?.breakdown?.marketplace || 0, revenue?.breakdown?.total || 0)}% du total
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Subscriptions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Abonnements actifs</CardTitle>
            <Badge variant="outline">{activeSubscribers.length} abonnés</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Fan</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Plan</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Prix/mois</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Depuis</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Prochain paiement</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(activeSubscribers || []).slice(0, 10).map((subscriber: CreatorSubscriber) => {
                  const planBadge = getSubscriptionPlanBadge(subscriber.plan || 'basic');
                  return (
                    <tr key={subscriber.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={subscriber.fanAvatar} />
                            <AvatarFallback>{subscriber.fanName[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium text-gray-900">{subscriber.fanName}</p>
                            <p className="text-xs text-gray-500">{subscriber.fanEmail}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge className={planBadge.className}>{planBadge.label}</Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="font-semibold text-gray-900">€{subscriber.pricePerMonth}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm text-gray-900">
                          {subscriber.subscribedSince.toLocaleDateString('fr-FR')}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm text-gray-900">
                          {subscriber.nextRenewal.toLocaleDateString('fr-FR')}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewSubscriber(subscriber.id, subscriber.fanId)}
                          >
                            Voir
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-red-600 hover:bg-red-50"
                            onClick={() => handleCancelSubscription(subscriber.id, subscriber.fanName)}
                          >
                            Annuler
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Tips Received */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-pink-600" />
              Tips reçus
            </CardTitle>
            <div className="text-right">
              <p className="text-sm text-gray-600">Total tips</p>
              <p className="text-xl font-bold text-pink-600">€{tips.reduce((sum, t) => sum + t.amount, 0).toFixed(2)}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Tips */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Tips récents</h3>
              <div className="space-y-2">
                {tips.slice(0, 5).map((tip) => (
                  <div key={tip.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={tip.fanAvatar} />
                        <AvatarFallback>{tip.fanName[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{tip.fanName}</p>
                        {tip.message && <p className="text-xs text-gray-500 truncate max-w-[200px]">{tip.message}</p>}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-pink-600">€{tip.amount.toFixed(2)}</p>
                      <p className="text-xs text-gray-500">{tip.date.toLocaleDateString('fr-FR')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Tippers */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Top tippers</h3>
              <div className="space-y-2">
                {topTippers.map((tipper, index) => (
                  <div key={tipper.fanId} className="flex items-center justify-between p-3 bg-gradient-to-r from-pink-50 to-transparent rounded-lg border border-pink-100">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-6 h-6 bg-pink-600 text-white text-xs font-bold rounded-full">
                        {index + 1}
                      </div>
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={tipper.fanAvatar} />
                        <AvatarFallback>{tipper.fanName[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{tipper.fanName}</p>
                        <p className="text-xs text-gray-500">{tipper.count} tips</p>
                      </div>
                    </div>
                    <p className="text-sm font-bold text-pink-600">€{tipper.total.toFixed(2)}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PPV Sales */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-purple-600" />
              Ventes PPV
            </CardTitle>
            <Badge variant="outline">{ppvSales.length} ventes</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Contenu</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Fan acheteur</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Prix</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                </tr>
              </thead>
              <tbody>
                {ppvSales.map((sale) => (
                  <tr key={sale.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <p className="text-sm font-medium text-gray-900">{sale.contentTitle}</p>
                      <p className="text-xs text-gray-500">ID: {sale.contentId}</p>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={sale.fanAvatar} />
                          <AvatarFallback>{sale.fanName[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-gray-900">{sale.fanName}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="font-semibold text-gray-900">€{sale.price.toFixed(2)}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-gray-900">{sale.date.toLocaleDateString('fr-FR')}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Marketplace Transactions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-orange-600" />
              Transactions Marketplace
            </CardTitle>
            <Badge variant="outline">{marketplaceTransactions.length} commandes</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Annonce</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Fan client</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Montant</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(marketplaceTransactions || []).length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-gray-500 text-sm">
                      Aucune transaction marketplace
                    </td>
                  </tr>
                ) : (
                  (marketplaceTransactions as MarketplaceTransaction[]).slice(0, 5).map((transaction) => (
                    <tr key={transaction.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <p className="text-sm font-medium text-gray-900">{transaction.annonceTitle}</p>
                        <p className="text-xs text-gray-500">ID: {transaction.annonceId}</p>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm text-gray-900">{transaction.creatorUsername}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="font-semibold text-gray-900">€{transaction.amount.toFixed(2)}</span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="secondary">{transaction.statusLabel}</Badge>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm text-gray-900">
                          {new Date(transaction.date).toLocaleDateString('fr-FR')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewMarketplaceTransaction(transaction.id)}
                        >
                          Voir
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Payout History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-green-600" />
              Historique paiements plateforme
            </CardTitle>
            <Badge variant="outline">{payoutHistory.length} virements</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Période</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Montant brut</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Commission (15%)</th>
                  <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Net versé</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Date virement</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {payoutHistory.map((payout) => {
                  const statusBadge = getPayoutStatusBadge(payout.status);
                  const StatusIcon = statusBadge.icon;
                  return (
                    <tr key={payout.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <span className="text-sm font-medium text-gray-900">{payout.period}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="text-sm text-gray-900">€{payout.grossAmount.toFixed(2)}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="text-sm text-red-600">-€{payout.platformFee.toFixed(2)}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="font-semibold text-green-600">€{payout.netAmount.toFixed(2)}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm text-gray-900">
                          {payout.transferDate.toLocaleDateString('fr-FR')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge className={statusBadge.className}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusBadge.label}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDownloadInvoice(payout.id)}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Rapport
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
